import { configureStore } from "@reduxjs/toolkit";
import auth from './authSlice'
import promotion from "./promotionSlice";
import region from "./regionSlice"


const store = configureStore({
    reducer:{
        auth,
        promotion,
        region,
    }
});

export default store;
