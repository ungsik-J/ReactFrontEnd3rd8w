import React from 'react'

const SubCategory = () => {
  return (
    <div>SubCategory</div>
  )
}

export default SubCategory